"use client";

import React, { useState, useEffect } from "react";
import { pixelSound, type PixelSoundName } from "./sound";
import { PIXEL_UI_VERSION } from "./version";
import {
  PixelIcon,
  PixelSprite,
  type PixelIconName,
  type PixelSpriteCharacter,
} from "./icons";

export type PixelTone =
  | "yellow"
  | "cyan"
  | "emerald"
  | "coral"
  | "violet"
  | "chalk"
  | "ink";

export type PixelColorTone = PixelTone;

const TONE_STYLES: Record<
  PixelTone,
  {
    bg: string;
    text: string;
    border: string;
    hex: string;
    cardClass: string;
  }
> = {
  yellow: {
    bg: "bg-[#FFD100]",
    text: "text-[#090B10]",
    border: "border-[#FFD100]",
    hex: "#FFD100",
    cardClass: "px-card-yellow",
  },
  cyan: {
    bg: "bg-[#00E5FF]",
    text: "text-[#090B10]",
    border: "border-[#00E5FF]",
    hex: "#00E5FF",
    cardClass: "px-card-cyan",
  },
  emerald: {
    bg: "bg-[#10B981]",
    text: "text-[#090B10]",
    border: "border-[#10B981]",
    hex: "#10B981",
    cardClass: "px-card-emerald",
  },
  coral: {
    bg: "bg-[#FF3355]",
    text: "text-[#090B10]",
    border: "border-[#FF3355]",
    hex: "#FF3355",
    cardClass: "px-card-coral",
  },
  violet: {
    bg: "bg-[#A855F7]",
    text: "text-[#090B10]",
    border: "border-[#A855F7]",
    hex: "#A855F7",
    cardClass: "px-card-violet",
  },
  chalk: {
    bg: "bg-[#F5F2EB]",
    text: "text-[#090B10]",
    border: "border-[#F5F2EB]",
    hex: "#F5F2EB",
    cardClass: "px-card-chalk",
  },
  ink: {
    bg: "bg-[#131824]",
    text: "text-[#F5F2EB]",
    border: "border-[#2A344B]",
    hex: "#131824",
    cardClass: "px-card",
  },
};

/** Tone -> Tailwind classes + hex lookup shared by every Pixel UI component. */
export const PIXEL_TONE_STYLES = TONE_STYLES;

/* ============================================================================
   1. TACTILE PIXEL BUTTON & 3D KEYCAP
   ============================================================================ */

export interface PixelButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  tone?: PixelTone;
  size?: "xs" | "sm" | "md" | "lg";
  icon?: PixelIconName;
  sound?: PixelSoundName;
  stepped?: boolean;
}

export function PixelButton({
  tone = "yellow",
  size = "md",
  icon,
  sound = "click",
  stepped = false,
  className = "",
  children,
  onClick,
  onMouseEnter,
  ...rest
}: PixelButtonProps) {
  const t = TONE_STYLES[tone];
  const sizeMap = {
    xs: "px-2.5 py-1 text-[11px]",
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2.5 text-xs sm:text-sm",
    lg: "px-6 py-3.5 text-sm sm:text-base",
  };

  return (
    <button
      type="button"
      onClick={(e) => {
        pixelSound.play(sound);
        onClick?.(e);
      }}
      onMouseEnter={(e) => {
        pixelSound.play("hover", { volume: 0.4 });
        onMouseEnter?.(e);
      }}
      className={`px-btn ${t.bg} ${t.text} ${sizeMap[size]} ${
        stepped ? "px-step-sm" : "rounded-none"
      } ${className}`}
      {...rest}
    >
      {icon && <PixelIcon name={icon} size={size === "lg" ? 18 : 15} />}
      <span>{children}</span>
    </button>
  );
}

export interface PixelKeycapProps {
  keyLabel: string;
  caption?: string;
  tone?: PixelTone;
  onTrigger?: () => void;
}

export function PixelKeycap({
  keyLabel,
  caption,
  tone = "chalk",
  onTrigger,
}: PixelKeycapProps) {
  const [pressed, setPressed] = useState(false);
  const t = TONE_STYLES[tone];

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key.toUpperCase() === keyLabel.toUpperCase()) {
        setPressed(true);
        pixelSound.play("click", { pitchMultiplier: 1.1 });
        onTrigger?.();
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.key.toUpperCase() === keyLabel.toUpperCase()) {
        setPressed(false);
      }
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [keyLabel, onTrigger]);

  return (
    <button
      type="button"
      onClick={() => {
        pixelSound.play("click", { pitchMultiplier: 1.1 });
        onTrigger?.();
      }}
      className={`px-3d-keycap ${t.bg} ${t.text} px-3.5 py-2.5 flex flex-col items-center justify-center min-w-[54px] ${
        pressed ? "is-pressed" : ""
      }`}
    >
      <span className="font-pixel text-sm font-bold leading-none">
        {keyLabel}
      </span>
      {caption && (
        <span className="font-mono-hud text-[10px] opacity-75 mt-1 uppercase">
          {caption}
        </span>
      )}
    </button>
  );
}

/* ============================================================================
   2. RETRO VHF ROTARY CHANNEL DIAL & HARDWARE DIP-SWITCH TOGGLE
   ============================================================================ */

export interface PixelToggleProps {
  checked: boolean;
  onChange: (next: boolean) => void;
  label?: string;
  tone?: PixelTone;
}

export function PixelToggle({
  checked,
  onChange,
  label,
  tone = "yellow",
}: PixelToggleProps) {
  const t = TONE_STYLES[tone];
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => {
        const next = !checked;
        pixelSound.play(next ? "toggleOn" : "toggleOff");
        onChange(next);
      }}
      className="inline-flex items-center gap-2.5 font-mono-hud text-xs cursor-pointer select-none"
    >
      <div
        className={`w-12 h-6 border-2 border-[#090B10] p-0.5 flex items-center transition-colors ${
          checked ? t.bg : "bg-[#1A2132]"
        }`}
        style={{ boxShadow: "3px 3px 0px #040508" }}
      >
        <div
          className={`w-5 h-4 bg-[#090B10] transition-transform duration-100 flex items-center justify-center ${
            checked ? "translate-x-5" : "translate-x-0"
          }`}
        >
          <span
            className={`w-1.5 h-1.5 ${
              checked ? "bg-[#10B981]" : "bg-[#64748B]"
            }`}
          />
        </div>
      </div>
      {label && <span className="font-bold text-[#F5F2EB]">{label}</span>}
    </button>
  );
}

export interface PixelCrankProps {
  angle: number;
  onChange: (nextAngle: number) => void;
  label?: string;
}

export function PixelCrank({ angle, onChange, label }: PixelCrankProps) {
  const stepRotate = (delta: number) => {
    const next = (angle + delta + 360) % 360;
    pixelSound.play("crank", {
      pitchMultiplier: 0.85 + (next / 360) * 0.45,
    });
    onChange(next);
  };

  const chNumber = Math.floor((angle / 360) * 12) + 1;

  return (
    <div className="inline-flex items-center gap-3 p-3 bg-[#111622] border-2 border-[#00E5FF] shadow-[4px_4px_0_#040508]">
      <div
        onClick={() => stepRotate(30)}
        title="Click to turn VHF/UHF Rotary Tuner (+30 deg)"
        className="relative w-14 h-14 rounded-full bg-[#1E2638] border-3 border-[#090B10] shadow-[inset_0_2px_4px_rgba(255,255,255,0.25),0_3px_0_#040508] flex items-center justify-center cursor-pointer select-none"
      >
        <div
          className="w-full h-full flex items-center justify-center transition-transform duration-150"
          style={{ transform: `rotate(${angle}deg)` }}
        >
          <div className="w-2.5 h-11 bg-[#D8D1C2] border-2 border-[#090B10] flex flex-col items-center justify-start pt-0.5">
            <span className="w-1.5 h-2.5 bg-[#FF3355]" />
          </div>
        </div>
      </div>
      <div className="font-mono-hud text-xs">
        <div className="text-[10px] font-bold text-[#00E5FF] uppercase">
          {label || "VHF ROTARY TUNER"}
        </div>
        <div className="text-sm font-black text-white">
          CH {chNumber < 10 ? `0${chNumber}` : chNumber} · {angle}°
        </div>
        <div className="flex items-center gap-1 mt-1">
          <button
            type="button"
            onClick={() => stepRotate(-30)}
            className="px-2.5 py-1 bg-[#1A2132] hover:bg-[#00E5FF] hover:text-[#090B10] text-[11px] font-bold border border-[#3A4560] cursor-pointer"
          >
            CH -
          </button>
          <button
            type="button"
            onClick={() => stepRotate(30)}
            className="px-2.5 py-1 bg-[#FFD100] text-[#090B10] text-[11px] font-bold border border-[#090B10] cursor-pointer"
          >
            CH +
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   3. SPEC CARDS, RETRO OS WINDOWS, 3.5" FLOPPY DISKS & ROM CARTRIDGES
   ============================================================================ */

export interface PixelCardProps {
  tone?: PixelTone;
  kicker?: string;
  title?: string;
  badge?: string;
  interactive?: boolean;
  ditherHeader?: boolean;
  className?: string;
  onClick?: () => void;
  children: React.ReactNode;
}

export function PixelCard({
  tone = "ink",
  kicker,
  title,
  badge,
  interactive = false,
  ditherHeader = false,
  className = "",
  onClick,
  children,
}: PixelCardProps) {
  const t = TONE_STYLES[tone];

  return (
    <div
      onClick={() => {
        if (onClick) {
          pixelSound.play("click");
          onClick();
        }
      }}
      className={`${t.cardClass} ${
        interactive || onClick ? "px-card-interactive cursor-pointer" : ""
      } ${className}`}
    >
      {(kicker || badge) && (
        <div
          className={`px-4 py-2 border-b-2 border-[#090B10] flex items-center justify-between gap-2 font-mono-hud text-[11px] font-bold ${
            tone === "chalk"
              ? "bg-[#FFD100] text-[#090B10]"
              : "bg-[#090B10] text-[#F5F2EB]"
          } ${ditherHeader ? "px-dither-dots" : ""}`}
        >
          <span
            className="uppercase tracking-wider truncate"
            style={{ color: tone === "chalk" ? "#090B10" : t.hex }}
          >
            {kicker}
          </span>
          {badge && (
            <span
              className="px-2 py-0.5 text-[10px] font-bold text-[#090B10] shrink-0"
              style={{ backgroundColor: tone === "ink" ? "#FFD100" : t.hex }}
            >
              {badge}
            </span>
          )}
        </div>
      )}
      <div className="p-5">
        {title && (
          <h3 className="font-display text-lg sm:text-xl font-black mb-2">
            {title}
          </h3>
        )}
        {children}
      </div>
    </div>
  );
}

export interface PixelWindowProps {
  title: string;
  subtitle?: string;
  tone?: PixelTone;
  statusLeft?: string;
  statusRight?: string;
  children: React.ReactNode;
  className?: string;
}

export function PixelWindow({
  title,
  subtitle,
  tone = "yellow",
  statusLeft,
  statusRight,
  children,
  className = "",
}: PixelWindowProps) {
  const [minimized, setMinimized] = useState(false);
  const t = TONE_STYLES[tone];

  return (
    <div
      className={`bg-[#0E121B] border-2 border-[#090B10] shadow-[6px_6px_0_#040508] overflow-hidden ${className}`}
      style={{ outline: `2px solid ${t.hex}` }}
    >
      {/* Retro Lab OS Titlebar */}
      <div
        className={`px-3.5 py-2 ${t.bg} ${t.text} border-b-2 border-[#090B10] flex items-center justify-between gap-2 select-none`}
      >
        <div className="flex items-center gap-2 min-w-0">
          <PixelIcon name="window" size={14} />
          <span className="font-pixel text-xs font-bold min-w-0 break-words sm:truncate">
            {title}
          </span>
          {subtitle && (
            <span className="hidden sm:inline-block font-mono-hud text-[10px] opacity-80 truncate">
              {"// "}
              {subtitle}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => {
              pixelSound.play("click");
              setMinimized(!minimized);
            }}
            className="w-6 h-6 bg-[#090B10] text-[#F5F2EB] font-mono-hud text-[11px] font-bold flex items-center justify-center hover:bg-[#FF3355] cursor-pointer"
            title={minimized ? "Expand window" : "Minimize window"}
          >
            {minimized ? "+" : "-"}
          </button>
          <span aria-hidden="true" className="w-6 h-6 bg-[#090B10] text-[#F5F2EB] font-mono-hud text-[11px] font-bold flex items-center justify-center">
            □
          </span>
        </div>
      </div>

      {!minimized && <div className="p-4 sm:p-5">{children}</div>}

      {(statusLeft || statusRight) && (
        <div className="px-3.5 py-1.5 bg-[#090B10] border-t border-white/10 flex items-center justify-between font-mono-hud text-[10px] text-[#94A3B8]">
          <span>{statusLeft || "READY"}</span>
          <span style={{ color: t.hex }}>{statusRight}</span>
        </div>
      )}
    </div>
  );
}

export interface PixelFloppyCardProps {
  diskCode: string;
  title: string;
  capacity?: string;
  description: string;
  tone?: PixelTone;
  onInsert?: () => void;
}

export function PixelFloppyCard({
  diskCode,
  title,
  capacity = "1.44 MB HD",
  description,
  tone = "cyan",
  onInsert,
}: PixelFloppyCardProps) {
  const t = TONE_STYLES[tone];
  return (
    <div
      onClick={() => {
        pixelSound.play("cartridgeInsert");
        onInsert?.();
      }}
      className="group relative bg-[#182032] border-3 border-[#090B10] shadow-[6px_6px_0_#040508] p-4 pt-12 cursor-pointer select-none transition hover:-translate-y-1"
      style={{ outline: `2px solid ${t.hex}` }}
    >
      {/* Top 3.5" Metal Sliding Shutter */}
      <div className="absolute top-0 left-6 right-10 h-9 bg-[#CBD5E1] border-x-2 border-b-2 border-[#090B10] flex items-center justify-between px-3 transition-transform duration-200 group-hover:translate-x-2">
        <div className="w-4 h-6 bg-[#090B10]" />
        <span className="font-pixel text-[10px] text-[#090B10] font-bold">
          {diskCode} {"//"} {capacity}
        </span>
      </div>

      {/* Floppy Label Sticker */}
      <div className="bg-[#F5F2EB] text-[#090B10] border-2 border-[#090B10] p-3.5 space-y-2">
        <div
          className="h-2 w-full"
          style={{ backgroundColor: t.hex }}
        />
        <div className="font-display text-sm sm:text-base font-black leading-snug">
          {title}
        </div>
        <p className="font-mono-hud text-[11px] text-[#090B10]/80 leading-relaxed">
          {description}
        </p>
        <div className="pt-1 border-t border-[#090B10]/20 flex items-center justify-between font-pixel text-[10px]">
          <span>SECTOR 00 // ZERO-SHOT</span>
          <span className="px-1.5 py-0.5 bg-[#090B10] text-[#FFD100]">
            LOAD DISK ▶
          </span>
        </div>
      </div>
    </div>
  );
}

export interface Pixel3DCartridgeProps {
  code: string;
  title: string;
  subtitle: string;
  score: string;
  timeLabel: string;
  costLabel: string;
  tone?: PixelTone;
  thumb?: string;
  active?: boolean;
  onSelect?: () => void;
}

export function Pixel3DCartridge({
  code,
  title,
  subtitle,
  score,
  timeLabel,
  costLabel,
  tone = "yellow",
  thumb,
  active = false,
  onSelect,
}: Pixel3DCartridgeProps) {
  const t = TONE_STYLES[tone];

  return (
    <div
      onClick={() => {
        pixelSound.play("cartridgeInsert");
        onSelect?.();
      }}
      className={`px-3d-cartridge bg-[#151B29] p-3.5 cursor-pointer select-none flex flex-col justify-between ${
        active ? "ring-2 ring-[#FFD100]" : ""
      }`}
      style={{ borderColor: t.hex }}
    >
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex flex-col gap-1 w-14">
          <div className="h-1 bg-white/20" />
          <div className="h-1 bg-white/20" />
          <div className="h-1 bg-white/20" />
        </div>
        <span
          className={`px-2 py-0.5 font-pixel text-[10px] font-bold ${t.bg} ${t.text} border border-[#090B10]`}
        >
          {code}
        </span>
      </div>

      <div className="bg-[#090B10] border-2 border-[#040508] p-2.5 space-y-2">
        {thumb && (
          <div className="relative aspect-video overflow-hidden border border-white/15">
            <img
              src={thumb}
              alt={title}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 bg-[#090B10]/90 border border-white/20 font-mono-hud text-[10px] font-bold text-[#FFD100]">
              {score}
            </div>
          </div>
        )}
        <div>
          <div
            className="font-pixel text-xs font-bold leading-snug"
            style={{ color: t.hex }}
          >
            {title}
          </div>
          <div className="font-mono-hud text-[10px] text-[#94A3B8] mt-0.5 line-clamp-1">
            {subtitle}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-1.5 pt-1 font-mono-hud text-[10px]">
          <div className="px-2 py-1 bg-[#131824] border border-white/10 flex items-center gap-1 text-[#F5F2EB]">
            <PixelIcon name="clock" size={11} color="#00E5FF" />
            <span className="truncate">{timeLabel}</span>
          </div>
          <div className="px-2 py-1 bg-[#131824] border border-white/10 flex items-center gap-1 text-[#FFD100]">
            <PixelIcon name="coin" size={11} color="#FFD100" />
            <span className="truncate">{costLabel}</span>
          </div>
        </div>
      </div>

      <div className="mt-2.5 pt-1.5 border-t border-white/10 flex items-center justify-between px-2">
        <div className="flex items-center gap-1">
          {Array.from({ length: 8 }).map((_, i) => (
            <span
              key={i}
              className="w-1.5 h-2.5 bg-[#FFD100] border border-[#090B10]"
            />
          ))}
        </div>
        <span className="font-mono-hud text-[10px] font-bold text-[#94A3B8] uppercase">
          INSERT ROM →
        </span>
      </div>
    </div>
  );
}

/* ============================================================================
   4. 3D RETRO CRT COMPUTER & TELE-MONITOR WORKSTATION ("MIXIUH CRT-9000")
   100% Original Retro TV / Lab Computer with Working Channels, Degauss,
   Phosphor Modes, Power Switch & Zero Text Overflow!
   ============================================================================ */

export interface PocketConsoleCartridgeItem {
  id: string;
  code: string;
  kicker: string;
  title: string;
  verdict: string;
  timeMetric: string;
  costMetric: string;
  thumb: string;
  accentHex: string;
  character: PixelSpriteCharacter;
  onLaunchPrimary: () => void;
  onLaunchSecondary?: () => void;
  primaryLabel: string;
  secondaryLabel?: string;
}

export interface Pixel3DPocketConsoleProps {
  items: PocketConsoleCartridgeItem[];
  lang?: "es" | "en";
}

export function Pixel3DCRTWorkstation({
  items,
  lang = "es",
}: Pixel3DPocketConsoleProps) {
  const [idx, setIdx] = useState(0);
  const [poweredOn, setPoweredOn] = useState(true);
  const [staticFlash, setStaticFlash] = useState(false);
  const [degaussing, setDegaussing] = useState(false);
  const [crtMode, setCrtMode] = useState<"rgb" | "amber" | "green" | "mono">(
    "rgb"
  );

  const current = items[idx] || items[0];
  if (!current) return null;

  const switchChannel = (nextIdx: number) => {
    const safeIdx = (nextIdx + items.length) % items.length;
    setIdx(safeIdx);
    setStaticFlash(true);
    pixelSound.play("cartridgeInsert");
    setTimeout(() => setStaticFlash(false), 140);
  };

  const triggerDegauss = () => {
    setDegaussing(true);
    pixelSound.play("laser", { pitchMultiplier: 0.55 });
    setTimeout(() => setDegaussing(false), 450);
  };

  const cyclePhosphorMode = () => {
    const order: ("rgb" | "amber" | "green" | "mono")[] = [
      "rgb",
      "amber",
      "green",
      "mono",
    ];
    const next = order[(order.indexOf(crtMode) + 1) % order.length];
    setCrtMode(next);
    pixelSound.play("click", { pitchMultiplier: 1.25 });
  };

  const togglePower = () => {
    const next = !poweredOn;
    setPoweredOn(next);
    pixelSound.play(next ? "powerup" : "hit");
  };

  const filterClass =
    crtMode === "amber"
      ? "px-crt-filter-amber"
      : crtMode === "green"
      ? "px-crt-filter-green"
      : crtMode === "mono"
      ? "px-crt-filter-mono"
      : "";

  return (
    <div className="px-3d-stage w-full">
      {/* UPPER 3D CRT MONITOR CHASSIS */}
      <div
        className={`px-3d-crt-shell p-3.5 sm:p-4 text-[#090B10] ${
          degaussing ? "px-degauss-active" : ""
        }`}
      >
        {/* Monitor Top Ventilation Slots & Model Plate */}
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <span
              className={`w-2.5 h-2.5 rounded-full border border-[#090B10] shrink-0 ${
                poweredOn ? "bg-[#10B981]" : "bg-[#FF3355]"
              }`}
            />
            <span className="font-pixel text-[10px] font-bold tracking-wider truncate">
              {lang === "es"
                ? "MIXIUH LABS // MONITOR DE PRUEBAS"
                : "MIXIUH LABS // BENCHMARK MONITOR"}
            </span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="px-2 py-0.5 bg-[#090B10] text-[#FFD100] font-pixel text-[10px]">
              CH 0{idx + 1}/0{items.length}
            </span>
            <span className="px-2 py-0.5 bg-[#090B10] text-[#00E5FF] font-pixel text-[10px] uppercase">
              {crtMode}
            </span>
          </div>
        </div>

        {/* CRT Recessed Dark Glass Tube — Constant Height Whether Powered ON or OFF */}
        <div className="px-3d-screen-bezel p-2.5 sm:p-3 text-[#F5F2EB] space-y-2.5 overflow-hidden">
          {/* Top OSD Telemetry Bar inside CRT (Constant Height) */}
          <div className="flex items-center justify-between gap-2 font-mono-hud text-[10px] min-w-0 h-5">
            <span
              className="px-2 py-0.5 font-bold text-[#090B10] truncate"
              style={{
                backgroundColor: poweredOn ? current.accentHex : "#475569",
              }}
            >
              {poweredOn ? current.kicker : "STANDBY // CRT POWER OFF"}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <span className="inline-flex items-center gap-1 text-[#00E5FF] font-bold">
                <PixelIcon name="clock" size={11} color="#00E5FF" />
                <span>{current.timeMetric}</span>
              </span>
              <span className="inline-flex items-center gap-1 text-[#FFD100] font-bold">
                <PixelIcon name="coin" size={11} color="#FFD100" />
                <span>{current.costMetric}</span>
              </span>
            </div>
          </div>

          {/* 16:9 CRT Phosphor Screen with Scanlines (Identical aspect-video dimensions ON or OFF) */}
          {poweredOn ? (
            <div
              onClick={() => {
                pixelSound.play("powerup");
                current.onLaunchPrimary();
              }}
              className={`relative aspect-video overflow-hidden border-2 border-[#2A344B] bg-[#05070B] group cursor-pointer ${filterClass}`}
            >
              {staticFlash ? (
                <div className="w-full h-full px-dither-checker bg-[#1E293B] flex items-center justify-center">
                  <span className="font-pixel text-sm text-[#FFD100]">
                    TUNING CH 0{idx + 1} {"//"} {current.code}...
                  </span>
                </div>
              ) : (
                <>
                  <img
                    src={current.thumb}
                    alt={current.title}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-200"
                  />
                  {/* Subtle CRT Scanline Overlay */}
                  <div className="absolute inset-0 px-crt-scanlines pointer-events-none" />
                  {/* Top-Left Green OSD Channel Indicator */}
                  <div className="absolute top-2 left-2 px-2 py-0.5 bg-[#090B10] border border-[#10B981] font-pixel text-[10px] text-[#10B981]">
                    CH 0{idx + 1} · {current.code}
                  </div>
                  {/* Floating Character Sprite in Corner */}
                  <div className="absolute bottom-2 right-2 p-1 bg-[#090B10] border border-white/25">
                    <PixelSprite character={current.character} size={28} />
                  </div>
                </>
              )}
            </div>
          ) : (
            <div
              onClick={togglePower}
              className="relative aspect-video overflow-hidden bg-[#040508] border-2 border-[#1E2638] flex flex-col items-center justify-center gap-3 cursor-pointer"
            >
              <div className="w-2/3 h-0.5 bg-[#F5F2EB] shadow-[0_0_12px_#00E5FF]" />
              <span className="font-pixel text-[10px] text-[#94A3B8]">
                CRT STANDBY // CLICK PWR TO BOOT
              </span>
            </div>
          )}

          {/* Dedicated Non-Overflowing OSD Episode Title & Verdict Box (Constant Height) */}
          <div className="p-2.5 bg-[#111622] border border-[#2A344B] min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <span
                className="font-pixel text-[10px] font-bold truncate"
                style={{
                  color: poweredOn ? current.accentHex : "#94A3B8",
                }}
              >
                {poweredOn
                  ? current.verdict
                  : lang === "es"
                  ? "TUBO CATODICO EN REPOSO · PRESIONA PWR PARA ENCENDER"
                  : "CRT TUBE IN STANDBY · PRESS PWR TO RESUME"}
              </span>
              <span className="font-mono-hud text-[10px] text-[#94A3B8] shrink-0">
                {poweredOn ? "60Hz LOCK" : "0Hz OFF"}
              </span>
            </div>
            <div className="font-display text-xs sm:text-sm font-black text-white leading-snug line-clamp-2 min-h-[2.75em]">
              {current.title}
            </div>
          </div>

          {/* Physical VHF Channel Push-Buttons inside Monitor Bezel */}
          <div className="grid grid-cols-3 min-[420px]:grid-cols-5 gap-1 pt-0.5">
            {items.map((item, i) => (
              <button
                key={item.id}
                type="button"
                onClick={() => switchChannel(i)}
                className={`py-1.5 px-1 font-pixel text-[10px] border-2 transition cursor-pointer truncate ${
                  i === idx
                    ? "bg-[#FFD100] text-[#090B10] border-[#090B10] font-bold shadow-[2px_2px_0_#00E5FF]"
                    : "bg-[#131824] text-[#94A3B8] border-[#2A344B] hover:text-white"
                }`}
              >
                {item.code}
              </button>
            ))}
          </div>
        </div>

        {/* Monitor Front Panel Hardware Controls: CH -, CH +, DEGAUSS, CRT MODE, POWER */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-1.5">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => switchChannel(idx - 1)}
              className="px-2.5 py-1.5 bg-[#131824] hover:bg-[#090B10] text-[#F5F2EB] border-2 border-[#090B10] shadow-[2px_2px_0_#040508] active:translate-y-0.5 font-pixel text-[10px] font-bold cursor-pointer"
              title={lang === "es" ? "Canal Anterior" : "Previous Channel"}
            >
              ◀ CH
            </button>
            <button
              type="button"
              onClick={() => switchChannel(idx + 1)}
              className="px-2.5 py-1.5 bg-[#131824] hover:bg-[#090B10] text-[#F5F2EB] border-2 border-[#090B10] shadow-[2px_2px_0_#040508] active:translate-y-0.5 font-pixel text-[10px] font-bold cursor-pointer"
              title={lang === "es" ? "Siguiente Canal" : "Next Channel"}
            >
              CH ▶
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={triggerDegauss}
              className="px-2.5 py-1.5 bg-[#00E5FF] text-[#090B10] border-2 border-[#090B10] shadow-[2px_2px_0_#040508] active:translate-y-0.5 font-pixel text-[10px] font-bold cursor-pointer"
              title="Magnetic CRT Degauss Coil"
            >
              DEGAUSS
            </button>
            <button
              type="button"
              onClick={cyclePhosphorMode}
              className="px-2.5 py-1.5 bg-[#FFD100] text-[#090B10] border-2 border-[#090B10] shadow-[2px_2px_0_#040508] active:translate-y-0.5 font-pixel text-[10px] font-bold cursor-pointer"
              title="Cycle CRT Phosphor Filter (RGB / Amber / Green / Mono)"
            >
              CRT: {crtMode.toUpperCase()}
            </button>
            <button
              type="button"
              onClick={togglePower}
              className={`px-2.5 py-1.5 border-2 border-[#090B10] shadow-[2px_2px_0_#040508] active:translate-y-0.5 font-pixel text-[10px] font-bold cursor-pointer ${
                poweredOn
                  ? "bg-[#10B981] text-[#090B10]"
                  : "bg-[#FF3355] text-[#090B10]"
              }`}
              title="Toggle CRT Power"
            >
              PWR
            </button>
          </div>
        </div>
      </div>

      {/* LOWER 3D RETRO COMPUTER FLOPPY DRIVE & FUNCTIONAL KEYBOARD ACTION DECK */}
      <div className="px-3d-crt-deck mx-2 p-3 text-[#090B10] space-y-2.5">
        {/* 3.5" Floppy Drive Slot & Activity LED */}
        <div className="flex items-center justify-between gap-3 px-2 py-1.5 bg-[#090B10] text-[#F5F2EB] border-2 border-[#040508]">
          <div className="flex items-center gap-2 min-w-0">
            <PixelIcon name="floppy" size={13} color="#FFD100" />
            <span className="font-mono-hud text-[10px] font-bold text-[#94A3B8] truncate">
              DRIVE A: // {current.code}_MASTER.ROM
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="w-2 h-2 bg-[#10B981] animate-px-blink" />
            <span className="font-pixel text-[10px] text-[#FFD100]">READY</span>
          </div>
        </div>

        {/* 100% Visible, Non-Clipping Mechanical Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          <button
            type="button"
            onClick={() => {
              pixelSound.play("powerup");
              current.onLaunchPrimary();
            }}
            className={`${
              current.onLaunchSecondary ? "sm:col-span-8" : "sm:col-span-12"
            } py-2.5 px-3 bg-[#090B10] hover:bg-[#131824] text-[#FFD100] border-2 border-[#090B10] shadow-[3px_3px_0_rgba(0,0,0,0.4)] active:translate-y-0.5 font-pixel text-[10px] font-bold flex items-center justify-center gap-2 cursor-pointer`}
          >
            <PixelIcon name="play" size={13} color="#FFD100" />
            <span className="text-left leading-snug">{current.primaryLabel}</span>
          </button>

          {current.onLaunchSecondary && (
            <button
              type="button"
              onClick={() => {
                pixelSound.play("coin");
                current.onLaunchSecondary?.();
              }}
              className="sm:col-span-4 py-2.5 px-3 bg-[#00E5FF] hover:brightness-105 text-[#090B10] border-2 border-[#090B10] shadow-[3px_3px_0_rgba(0,0,0,0.4)] active:translate-y-0.5 font-pixel text-[10px] font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <PixelIcon name="gamepad" size={13} color="#090B10" />
              <span className="truncate">
                {current.secondaryLabel || "SIMULADOR"}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// Keep alias so imports of Pixel3DPocketConsole automatically use the new CRT Workstation
export const Pixel3DPocketConsole = Pixel3DCRTWorkstation;

/* ============================================================================
   5. PIXEL-ART CHARTS, GAUGES & TELEMETRY VISUALIZATIONS
   ============================================================================ */

export interface PixelBarChartItem {
  label: string;
  value: number;
  maxValue?: number;
  displayValue: string;
  tone?: PixelTone;
  badge?: string;
}

export function PixelBarChart({
  items,
  segments = 16,
}: {
  items: PixelBarChartItem[];
  segments?: number;
}) {
  const maxVal = Math.max(...items.map((i) => i.maxValue || i.value), 1);

  return (
    <div className="space-y-3 font-mono-hud">
      {items.map((item) => {
        const t = TONE_STYLES[item.tone || "yellow"];
        const ratio = Math.min(1, Math.max(0, item.value / maxVal));
        const activeCount = Math.max(1, Math.round(ratio * segments));

        return (
          <div key={item.label} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-[#F5F2EB]">{item.label}</span>
              <div className="flex items-center gap-2">
                {item.badge && (
                  <span
                    className={`px-1.5 py-0.5 text-[10px] font-bold ${t.bg} ${t.text}`}
                  >
                    {item.badge}
                  </span>
                )}
                <span className="font-bold" style={{ color: t.hex }}>
                  {item.displayValue}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-16 gap-1 p-1 bg-[#090B10] border-2 border-[#2A344B]">
              {Array.from({ length: segments }).map((_, idx) => (
                <div
                  key={idx}
                  className="h-3.5 transition-all duration-150"
                  style={{
                    backgroundColor:
                      idx < activeCount ? t.hex : "rgba(255,255,255,0.06)",
                  }}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function PixelVersusBar({
  leftName,
  leftScore,
  leftTone = "cyan",
  rightName,
  rightScore,
  rightTone = "coral",
  subtitle,
}: {
  leftName: string;
  leftScore: number;
  leftTone?: PixelTone;
  rightName: string;
  rightScore: number;
  rightTone?: PixelTone;
  subtitle?: string;
}) {
  const total = Math.max(1, leftScore + rightScore);
  const leftPct = Math.round((leftScore / total) * 100);
  const lt = TONE_STYLES[leftTone];
  const rt = TONE_STYLES[rightTone];

  return (
    <div className="p-3.5 bg-[#090B10] border-2 border-[#2A344B] space-y-2 font-mono-hud">
      <div className="flex items-center justify-between text-xs font-bold">
        <span style={{ color: lt.hex }}>
          {leftName} [{leftScore}]
        </span>
        <span className="px-2 py-0.5 bg-[#FFD100] text-[#090B10] font-pixel text-[10px]">
          VS
        </span>
        <span style={{ color: rt.hex }}>
          [{rightScore}] {rightName}
        </span>
      </div>
      <div className="h-5 w-full bg-[#131824] border-2 border-[#040508] flex overflow-hidden">
        <div
          style={{ width: `${leftPct}%`, backgroundColor: lt.hex }}
          className="h-full border-r-2 border-[#090B10] transition-all duration-300"
        />
        <div
          style={{ width: `${100 - leftPct}%`, backgroundColor: rt.hex }}
          className="h-full transition-all duration-300"
        />
      </div>
      {subtitle && (
        <div className="text-[10px] text-center text-[#94A3B8]">{subtitle}</div>
      )}
    </div>
  );
}

export function PixelSparkline({
  data,
  tone = "cyan",
  label,
  currentValue,
}: {
  data: number[];
  tone?: PixelTone;
  label: string;
  currentValue: string;
}) {
  const t = TONE_STYLES[tone];
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = Math.max(1, max - min);

  return (
    <div className="p-3.5 bg-[#090B10] border-2 border-[#2A344B] font-mono-hud">
      <div className="flex items-center justify-between text-xs mb-2">
        <span className="text-[#94A3B8] font-bold uppercase">{label}</span>
        <span className="font-pixel text-xs font-bold" style={{ color: t.hex }}>
          {currentValue}
        </span>
      </div>
      <div className="h-16 flex items-end gap-1 pt-2 px-1 bg-[#111622] border border-white/10 px-dither-dots">
        {data.map((v, idx) => {
          const hPct = Math.max(12, Math.round(((v - min) / range) * 100));
          return (
            <div
              key={idx}
              className="flex-1 transition-all"
              style={{
                height: `${hPct}%`,
                backgroundColor:
                  idx === data.length - 1 ? "#FFD100" : t.hex,
              }}
            />
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================================
   6. INTERACTIVE 8-BIT CHIPTUNE STEP SEQUENCER (<PixelAudioSequencer />)
   ============================================================================ */

const SEQ_TRACKS = [
  { name: "LEAD (C6)", sound: "coin" as PixelSoundName, pitch: 1.2, color: "#00E5FF" },
  { name: "SYNTH (G5)", sound: "toggleOn" as PixelSoundName, pitch: 1.0, color: "#FFD100" },
  { name: "BASS (C4)", sound: "crank" as PixelSoundName, pitch: 0.75, color: "#10B981" },
  { name: "PERC (HIT)", sound: "click" as PixelSoundName, pitch: 0.9, color: "#FF3355" },
];

export function PixelAudioSequencer() {
  const [grid, setGrid] = useState<boolean[][]>([
    [true, false, false, true, false, true, false, false],
    [false, false, true, false, true, false, false, true],
    [true, false, true, false, true, false, true, false],
    [true, false, false, false, true, false, false, true],
  ]);
  const [playing, setPlaying] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => {
      setStep((prev) => {
        const next = (prev + 1) % 8;
        grid.forEach((row, rIdx) => {
          if (row[next]) {
            const tr = SEQ_TRACKS[rIdx];
            pixelSound.play(tr.sound, {
              pitchMultiplier: tr.pitch + (next % 3) * 0.08,
              volume: 0.65,
            });
          }
        });
        return next;
      });
    }, 185);
    return () => clearInterval(timer);
  }, [playing, grid]);

  const toggleCell = (r: number, c: number) => {
    const next = grid.map((row, ri) =>
      row.map((val, ci) => (ri === r && ci === c ? !val : val))
    );
    setGrid(next);
    if (!grid[r][c]) {
      pixelSound.play(SEQ_TRACKS[r].sound, {
        pitchMultiplier: SEQ_TRACKS[r].pitch,
      });
    }
  };

  return (
    <div className="p-4 bg-[#090B10] border-2 border-[#2A344B] space-y-3 font-mono-hud">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <PixelIcon name="music" size={15} color="#FFD100" />
          <span className="font-pixel text-xs text-[#FFD100] font-bold">
            8-BIT CHIPTUNE STEP SEQUENCER (4x8)
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setPlaying(!playing)}
            className={`px-3 py-1 font-pixel text-[10px] font-bold border-2 border-[#090B10] cursor-pointer ${
              playing
                ? "bg-[#FF3355] text-[#090B10]"
                : "bg-[#10B981] text-[#090B10]"
            }`}
          >
            {playing ? "■ STOP LOOP" : "▶ PLAY 8-BIT LOOP"}
          </button>
        </div>
      </div>

      <div className="space-y-1.5">
        {SEQ_TRACKS.map((tr, rIdx) => (
          <div key={tr.name} className="grid grid-cols-12 gap-1.5 items-center">
            <span
              className="col-span-4 sm:col-span-3 font-pixel text-[10px] truncate"
              style={{ color: tr.color }}
            >
              {tr.name}
            </span>
            <div className="col-span-8 sm:col-span-9 grid grid-cols-8 gap-1">
              {grid[rIdx].map((active, cIdx) => {
                const isCur = playing && step === cIdx;
                return (
                  <button
                    key={cIdx}
                    type="button"
                    onClick={() => toggleCell(rIdx, cIdx)}
                    className={`h-6 border transition cursor-pointer ${
                      isCur ? "ring-2 ring-white" : "border-[#2A344B]"
                    }`}
                    style={{
                      backgroundColor: active ? tr.color : "#131824",
                    }}
                  />
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
   7. RPG TYPEWRITER DIALOG BOX WITH VOICE BLIPS
   ============================================================================ */

export interface PixelDialogBoxProps {
  speaker: string;
  role?: string;
  character?: PixelSpriteCharacter;
  messages: string[];
  tone?: PixelTone;
}

export function PixelDialogBox({
  speaker,
  role,
  character = "mixiuh",
  messages,
  tone = "yellow",
}: PixelDialogBoxProps) {
  const [msgIdx, setMsgIdx] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const fullText = messages[msgIdx] || "";
  const t = TONE_STYLES[tone];

  // Restart the typewriter whenever the visible message changes (adjusting
  // state during render avoids an extra effect pass with stale text)
  const [typedText, setTypedText] = useState(fullText);
  if (typedText !== fullText) {
    setTypedText(fullText);
    setCharCount(0);
  }

  useEffect(() => {
    if (charCount >= fullText.length) return;
    const timer = setTimeout(() => {
      setCharCount((c) => c + 1);
      if (charCount % 3 === 0) {
        pixelSound.play("dialogBlip", {
          pitchMultiplier: character === "opus" ? 0.85 : 1.05,
          volume: 0.35,
        });
      }
    }, 22);
    return () => clearTimeout(timer);
  }, [charCount, fullText, character]);

  const handleNext = () => {
    if (charCount < fullText.length) {
      setCharCount(fullText.length);
      pixelSound.play("click");
    } else {
      setMsgIdx((i) => (i + 1) % messages.length);
      pixelSound.play("coin");
    }
  };

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`${speaker}: ${fullText}`}
      onClick={handleNext}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleNext();
        }
      }}
      className="p-4 bg-[#090B10] border-2 border-[#FFD100] shadow-[6px_6px_0_#040508] flex items-start gap-4 cursor-pointer select-none"
      style={{ borderColor: t.hex }}
    >
      <div className="p-2 bg-[#131824] border-2 border-[#2A344B] shrink-0">
        <PixelSprite character={character} size={48} />
      </div>
      <div className="flex-1 min-w-0 font-mono-hud">
        <div className="flex items-center justify-between gap-2 mb-1">
          <div className="flex items-center gap-2">
            <span
              className="font-pixel text-xs font-bold"
              style={{ color: t.hex }}
            >
              {speaker}
            </span>
            {role && (
              <span className="text-[10px] text-[#94A3B8]">{`// ${role}`}</span>
            )}
          </div>
          <span className="text-[10px] text-[#94A3B8]">
            [{msgIdx + 1}/{messages.length}]
          </span>
        </div>
        <p
          aria-hidden="true"
          className="text-xs sm:text-sm text-[#F5F2EB] leading-relaxed min-h-[42px]"
        >
          {fullText.slice(0, charCount)}
          <span className="inline-block w-2 h-3.5 bg-[#FFD100] ml-1 animate-px-blink align-middle" />
        </p>
        <div className="mt-2 flex items-center justify-end gap-1 text-[10px] font-bold text-[#FFD100]">
          <span>CLICK NEXT</span>
          <span className="animate-px-blink">▼</span>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   8. TELEMETRY PILLS (AGENTS.MD STANDARD: [CLOCK + MIN] & [COIN + $ USD])
   ============================================================================ */

export function PixelTelemetryPill({
  kind,
  value,
  tone = "cyan",
}: {
  kind: "time" | "cost" | "score" | "model";
  value: string;
  tone?: PixelTone;
}) {
  const t = TONE_STYLES[tone];
  const iconMap: Record<typeof kind, PixelIconName> = {
    time: "clock",
    cost: "coin",
    score: "trophy",
    model: "cpu",
  };

  return (
    <span
      className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#090B10] border font-mono-hud text-[11px] font-bold text-[#F5F2EB]"
      style={{ borderColor: t.hex }}
    >
      <PixelIcon name={iconMap[kind]} size={12} color={t.hex} />
      <span>{value}</span>
    </span>
  );
}

/* ============================================================================
   9. OPEN-SOURCE ATTRIBUTION COMPONENT (<PixelCreditBadge />)
   Required for free worldwide personal & commercial use of @mixiuh/pixel-ui
   ============================================================================ */

export interface PixelCreditBadgeProps {
  variant?: "minimal" | "pill" | "hardware" | "banner";
  className?: string;
}

export function PixelCreditBadge({
  variant = "pill",
  className = "",
}: PixelCreditBadgeProps) {
  if (variant === "minimal") {
    return (
      <a
        href="https://labs.mixiuh.online#pixel-ui"
        target="_blank"
        rel="noopener noreferrer"
        className={`inline-flex items-center gap-1.5 font-mono-hud text-[11px] text-[#94A3B8] hover:text-[#FFD100] transition ${className}`}
      >
        <PixelIcon name="crt-tv" size={13} color="#FFD100" />
        <span>
          UI powered by{" "}
          <strong className="text-[#F5F2EB]">Mixiuh Pixel UI</strong>
        </span>
      </a>
    );
  }

  if (variant === "hardware") {
    return (
      <a
        href="https://labs.mixiuh.online#pixel-ui"
        target="_blank"
        rel="noopener noreferrer"
        className={`inline-flex items-center gap-2.5 px-3 py-1.5 bg-[#FFD100] text-[#090B10] border-2 border-[#090B10] shadow-[4px_4px_0_#040508] font-mono-hud text-xs font-bold hover:brightness-105 transition ${className}`}
      >
        <span className="p-0.5 bg-[#090B10] border border-[#090B10] inline-flex">
          <PixelSprite character="mixiuh" size={20} animate={false} />
        </span>
        <div>
          <div className="font-pixel text-[10px] leading-none">
            {`MIXIUH PIXEL UI v${PIXEL_UI_VERSION}`}
          </div>
          <div className="text-[10px] font-bold opacity-80">
            OPEN SOURCE · LABS.MIXIUH.ONLINE
          </div>
        </div>
      </a>
    );
  }

  if (variant === "banner") {
    return (
      <div
        className={`p-3 bg-[#111622] border-2 border-[#00E5FF] shadow-[4px_4px_0_#040508] flex flex-wrap items-center justify-between gap-3 font-mono-hud text-xs ${className}`}
      >
        <div className="flex items-center gap-2.5">
          <PixelSprite character="mixiuh" size={28} />
          <div>
            <span className="font-pixel text-[#FFD100] font-bold">
              {`BUILT WITH MIXIUH PIXEL UI v${PIXEL_UI_VERSION}`}
            </span>
            <p className="text-[11px] text-[#94A3B8]">
              Free Open-Source Pixel-Art & Retro 3D CRT Component System by
              Mixiuh Labs.
            </p>
          </div>
        </div>
        <a
          href="https://labs.mixiuh.online#pixel-ui"
          target="_blank"
          rel="noopener noreferrer"
          className="px-3 py-1.5 bg-[#00E5FF] text-[#090B10] font-bold border border-[#090B10]"
        >
          labs.mixiuh.online →
        </a>
      </div>
    );
  }

  return (
    <a
      href="https://labs.mixiuh.online#pixel-ui"
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center gap-2 px-3 py-1 bg-[#090B10] border-2 border-[#FFD100] shadow-[3px_3px_0_#040508] font-mono-hud text-[11px] font-bold text-[#F5F2EB] hover:bg-[#131824] transition ${className}`}
    >
      <PixelIcon name="crt-tv" size={13} color="#FFD100" />
      <span>
        PIXEL UI BY <span className="text-[#FFD100]">MIXIUH LABS</span>
      </span>
    </a>
  );
}

/* ============================================================================
   10. PIXEL-ART SOCIAL MEDIA & COMMUNITY REDIRECT BAR (<PixelSocialBar />)
   ============================================================================ */

export interface PixelSocialLinkItem {
  id: string;
  label: string;
  sublabel?: string;
  href: string;
  icon: PixelIconName;
  accentHex: string;
}

export interface PixelSocialBarProps {
  links?: PixelSocialLinkItem[];
  compact?: boolean;
  className?: string;
}

export const DEFAULT_MIXIUH_SOCIAL_LINKS: PixelSocialLinkItem[] = [
  {
    id: "youtube-es",
    label: "YouTube ES",
    sublabel: "@MixiuhLabsES",
    href: "https://www.youtube.com/@MixiuhLabsES",
    icon: "youtube",
    accentHex: "#FF3355",
  },
  {
    id: "youtube-en",
    label: "YouTube EN",
    sublabel: "@MixiuhLabsEN",
    href: "https://www.youtube.com/@MixiuhLabsEN",
    icon: "youtube",
    accentHex: "#FFD100",
  },
  {
    id: "instagram",
    label: "Instagram",
    sublabel: "@labs.mixiuh",
    href: "https://www.instagram.com/labs.mixiuh",
    icon: "instagram",
    accentHex: "#F472B6",
  },
  {
    id: "tiktok",
    label: "TikTok",
    sublabel: "@mixiuhlabs",
    href: "https://www.tiktok.com/@mixiuhlabs",
    icon: "tiktok",
    accentHex: "#00E5FF",
  },
  {
    id: "x",
    label: "X",
    sublabel: "@MixiuhLabs",
    href: "https://x.com/MixiuhLabs",
    icon: "x",
    accentHex: "#F5F2EB",
  },
  {
    id: "github",
    label: "GitHub",
    sublabel: "Open Source",
    href: "https://github.com/mixiuh/mixiuh-labs-site",
    icon: "github",
    accentHex: "#10B981",
  },
  {
    id: "web",
    label: "Mixiuh Web",
    sublabel: "mixiuh.online",
    href: "https://mixiuh.online",
    icon: "globe",
    accentHex: "#A855F7",
  },
];

export function PixelSocialBar({
  links = DEFAULT_MIXIUH_SOCIAL_LINKS,
  compact = false,
  className = "",
}: PixelSocialBarProps) {
  if (compact) {
    return (
      <div className={`inline-flex flex-wrap items-center gap-1.5 ${className}`}>
        {links.map((item) => (
          <a
            key={item.id}
            href={item.href}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => pixelSound.play("coin")}
            title={`${item.label} (${item.sublabel || item.href})`}
            className="px-2.5 py-1.5 bg-[#111622] hover:bg-[#090B10] border-2 border-[#090B10] shadow-[3px_3px_0_#040508] inline-flex items-center gap-1.5 font-pixel text-[10px] font-bold text-[#F5F2EB] transition hover:-translate-y-0.5"
            style={{ outline: `1px solid ${item.accentHex}` }}
          >
            <PixelIcon name={item.icon} size={13} color={item.accentHex} />
            <span>{item.label}</span>
          </a>
        ))}
      </div>
    );
  }

  return (
    <div
      className={`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-2.5 ${className}`}
    >
      {links.map((item) => (
        <a
          key={item.id}
          href={item.href}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => pixelSound.play("coin")}
          className="p-3 bg-[#111622] hover:bg-[#171E2E] border-2 border-[#090B10] shadow-[4px_4px_0_#040508] flex items-center gap-2.5 transition hover:-translate-y-0.5"
          style={{ outline: `2px solid ${item.accentHex}` }}
        >
          <div
            className="w-8 h-8 border-2 border-[#090B10] flex items-center justify-center shrink-0"
            style={{ backgroundColor: item.accentHex }}
          >
            <PixelIcon name={item.icon} size={16} color="#090B10" />
          </div>
          <div className="min-w-0">
            <div className="font-pixel text-[10px] font-bold text-white break-words">
              {item.label}
            </div>
            {item.sublabel && (
              <div
                className="font-mono-hud text-[10px] font-bold break-words"
                style={{ color: item.accentHex }}
              >
                {item.sublabel}
              </div>
            )}
          </div>
        </a>
      ))}
    </div>
  );
}

/* ============================================================================
   11. PRO FORM, NAVIGATION, COLLAPSE, CALENDAR & DATA-VIZ SUITE (v2.2)
   ============================================================================ */

export interface PixelInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  label?: string;
  helperText?: string;
  errorText?: string;
  tone?: PixelColorTone;
  size?: "sm" | "md" | "lg";
  iconLeft?: PixelIconName;
  iconRight?: PixelIconName;
  clearable?: boolean;
  onClear?: () => void;
}

export function PixelInput({
  label,
  helperText,
  errorText,
  tone = "cyan",
  size = "md",
  iconLeft,
  iconRight,
  clearable = false,
  onClear,
  className = "",
  value,
  onChange,
  ...rest
}: PixelInputProps) {
  const accent = TONE_STYLES[tone].hex;
  const borderHex = errorText ? "#FF3355" : accent;
  const sizePad =
    size === "sm"
      ? "px-2.5 py-1.5 text-xs"
      : size === "lg"
      ? "px-4 py-3 text-sm"
      : "px-3 py-2 text-xs sm:text-sm";

  return (
    <div className={`space-y-1.5 font-mono-hud ${className}`}>
      {label && (
        <label className="block font-pixel text-[10px] font-bold text-[#F5F2EB] tracking-wider uppercase">
          {label}
        </label>
      )}
      <div
        className="relative flex items-center bg-[#090B10] border-2 border-[#090B10] shadow-[4px_4px_0_#040508]"
        style={{ outline: `2px solid ${borderHex}` }}
      >
        {iconLeft && (
          <span className="pl-3 pr-1 flex items-center shrink-0">
            <PixelIcon name={iconLeft} size={14} color={borderHex} />
          </span>
        )}
        <input
          value={value}
          onChange={(e) => {
            pixelSound.play("dialogBlip");
            onChange?.(e);
          }}
          className={`w-full bg-transparent text-[#F5F2EB] placeholder:text-[#64748B] focus:outline-none font-mono-hud ${sizePad}`}
          {...rest}
        />
        {clearable && value && String(value).length > 0 && (
          <button
            type="button"
            onClick={() => {
              pixelSound.play("click");
              onClear?.();
            }}
            className="pr-2.5 pl-1.5 py-2 text-[#94A3B8] hover:text-[#FF3355] cursor-pointer"
            title="Clear"
          >
            <PixelIcon name="close" size={13} color="currentColor" />
          </button>
        )}
        {iconRight && (
          <span className="pr-3 pl-1 flex items-center shrink-0">
            <PixelIcon name={iconRight} size={14} color={borderHex} />
          </span>
        )}
      </div>
      {errorText ? (
        <p className="text-[11px] text-[#FF3355] font-bold flex items-center gap-1">
          <PixelIcon name="bug" size={12} color="#FF3355" />
          <span>{errorText}</span>
        </p>
      ) : helperText ? (
        <p className="text-[11px] text-[#94A3B8]">{helperText}</p>
      ) : null}
    </div>
  );
}

export interface PixelSelectOption {
  value: string;
  label: string;
  sublabel?: string;
  badge?: string;
  icon?: PixelIconName;
}

export interface PixelSelectProps {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  options: PixelSelectOption[];
  placeholder?: string;
  tone?: PixelColorTone;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function PixelSelect({
  label,
  value,
  onChange,
  options,
  placeholder = "Seleccionar opcion...",
  tone = "yellow",
  size = "md",
  className = "",
}: PixelSelectProps) {
  const [open, setOpen] = useState(false);
  const accent = TONE_STYLES[tone].hex;
  const selected = options.find((o) => o.value === value);
  const sizePad =
    size === "sm"
      ? "px-2.5 py-1.5 text-xs"
      : size === "lg"
      ? "px-4 py-3 text-sm"
      : "px-3 py-2 text-xs sm:text-sm";

  return (
    <div className={`relative space-y-1.5 font-mono-hud ${className}`}>
      {label && (
        <label className="block font-pixel text-[10px] font-bold text-[#F5F2EB] tracking-wider uppercase">
          {label}
        </label>
      )}
      <button
        type="button"
        onClick={() => {
          pixelSound.play("click");
          setOpen((prev) => !prev);
        }}
        className={`w-full bg-[#090B10] hover:bg-[#111622] text-left text-[#F5F2EB] border-2 border-[#090B10] shadow-[4px_4px_0_#040508] flex items-center justify-between gap-2 cursor-pointer transition ${sizePad}`}
        style={{ outline: `2px solid ${accent}` }}
      >
        <div className="flex items-center gap-2 min-w-0">
          {selected?.icon && (
            <PixelIcon name={selected.icon} size={14} color={accent} />
          )}
          <span className="font-bold truncate">
            {selected ? selected.label : placeholder}
          </span>
          {selected?.sublabel && (
            <span className="text-[11px] text-[#94A3B8] truncate hidden sm:inline">
              · {selected.sublabel}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {selected?.badge && (
            <span
              className="px-1.5 py-0.5 font-pixel text-[10px] font-bold text-[#090B10]"
              style={{ backgroundColor: accent }}
            >
              {selected.badge}
            </span>
          )}
          <PixelIcon
            name={open ? "chevron-up" : "chevron-down"}
            size={14}
            color={accent}
          />
        </div>
      </button>

      {open && (
        <div
          className="absolute left-0 right-0 z-50 mt-1 bg-[#090B10] border-2 border-[#090B10] shadow-[6px_6px_0_#040508] max-h-60 overflow-y-auto divide-y divide-[#1E2638]"
          style={{ outline: `2px solid ${accent}` }}
        >
          {options.map((opt) => {
            const isSel = opt.value === value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  pixelSound.play("coin");
                  onChange(opt.value);
                  setOpen(false);
                }}
                className={`w-full px-3 py-2.5 text-left flex items-center justify-between gap-2 cursor-pointer transition ${
                  isSel
                    ? "bg-[#172033] text-white font-bold"
                    : "hover:bg-[#111622] text-[#CBD5E1]"
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  {opt.icon && (
                    <PixelIcon
                      name={opt.icon}
                      size={14}
                      color={isSel ? accent : "#94A3B8"}
                    />
                  )}
                  <div className="min-w-0">
                    <div className="text-xs font-bold truncate">{opt.label}</div>
                    {opt.sublabel && (
                      <div className="text-[10px] text-[#94A3B8] truncate">
                        {opt.sublabel}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {opt.badge && (
                    <span
                      className="px-1.5 py-0.5 font-pixel text-[10px] font-bold text-[#090B10]"
                      style={{ backgroundColor: accent }}
                    >
                      {opt.badge}
                    </span>
                  )}
                  {isSel && <PixelIcon name="check" size={13} color={accent} />}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

export interface PixelAutocompleteProps {
  label?: string;
  options: PixelSelectOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  tone?: PixelColorTone;
  className?: string;
}

export function PixelAutocomplete({
  label,
  options,
  value,
  onChange,
  placeholder = "Escribe para filtrar...",
  tone = "emerald",
  className = "",
}: PixelAutocompleteProps) {
  const accent = TONE_STYLES[tone].hex;
  const selectedObj = options.find((o) => o.value === value);
  const [query, setQuery] = useState(selectedObj?.label || "");
  const [open, setOpen] = useState(false);

  const filtered = options.filter(
    (o) =>
      o.label.toLowerCase().includes(query.trim().toLowerCase()) ||
      (o.sublabel &&
        o.sublabel.toLowerCase().includes(query.trim().toLowerCase())) ||
      (o.badge && o.badge.toLowerCase().includes(query.trim().toLowerCase()))
  );

  return (
    <div className={`relative space-y-1.5 font-mono-hud ${className}`}>
      {label && (
        <label className="block font-pixel text-[10px] font-bold text-[#F5F2EB] tracking-wider uppercase">
          {label}
        </label>
      )}
      <div
        className="flex items-center bg-[#090B10] border-2 border-[#090B10] shadow-[4px_4px_0_#040508]"
        style={{ outline: `2px solid ${accent}` }}
      >
        <span className="pl-3 pr-1 flex items-center shrink-0">
          <PixelIcon name="search" size={14} color={accent} />
        </span>
        <input
          type="text"
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            pixelSound.play("dialogBlip");
            setQuery(e.target.value);
            setOpen(true);
          }}
          placeholder={placeholder}
          className="w-full px-2.5 py-2 bg-transparent text-xs sm:text-sm text-[#F5F2EB] placeholder:text-[#64748B] focus:outline-none"
        />
        {query && (
          <button
            type="button"
            onClick={() => {
              pixelSound.play("click");
              setQuery("");
              setOpen(true);
            }}
            className="px-2.5 py-2 text-[#94A3B8] hover:text-white cursor-pointer"
          >
            <PixelIcon name="close" size={12} />
          </button>
        )}
        <button
          type="button"
          onClick={() => {
            pixelSound.play("click");
            setOpen((o) => !o);
          }}
          className="px-2.5 py-2 border-l border-[#1E2638] text-[#94A3B8] hover:text-white cursor-pointer"
        >
          <PixelIcon
            name={open ? "chevron-up" : "chevron-down"}
            size={13}
            color={accent}
          />
        </button>
      </div>

      {open && (
        <div
          className="absolute left-0 right-0 z-50 mt-1 bg-[#090B10] border-2 border-[#090B10] shadow-[6px_6px_0_#040508] max-h-56 overflow-y-auto divide-y divide-[#1E2638]"
          style={{ outline: `2px solid ${accent}` }}
        >
          {filtered.length === 0 ? (
            <div className="p-3 text-xs text-[#94A3B8] flex items-center justify-between">
              <span>Sin coincidencias para &ldquo;{query}&rdquo;</span>
              <PixelIcon name="ghost" size={14} color="#FF3355" />
            </div>
          ) : (
            filtered.map((opt) => {
              const isSel = opt.value === value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => {
                    pixelSound.play("powerup");
                    onChange(opt.value);
                    setQuery(opt.label);
                    setOpen(false);
                  }}
                  className={`w-full px-3 py-2 text-left flex items-center justify-between gap-2 cursor-pointer transition ${
                    isSel
                      ? "bg-[#172033] text-white font-bold"
                      : "hover:bg-[#111622] text-[#CBD5E1]"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {opt.icon && (
                      <PixelIcon name={opt.icon} size={14} color={accent} />
                    )}
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate">
                        {opt.label}
                      </div>
                      {opt.sublabel && (
                        <div className="text-[10px] text-[#94A3B8] truncate">
                          {opt.sublabel}
                        </div>
                      )}
                    </div>
                  </div>
                  {opt.badge && (
                    <span
                      className="px-1.5 py-0.5 font-pixel text-[10px] font-bold text-[#090B10] shrink-0"
                      style={{ backgroundColor: accent }}
                    >
                      {opt.badge}
                    </span>
                  )}
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

export interface PixelCheckboxProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description?: string;
  tone?: PixelColorTone;
  disabled?: boolean;
  className?: string;
}

export function PixelCheckbox({
  checked,
  onChange,
  label,
  description,
  tone = "yellow",
  disabled = false,
  className = "",
}: PixelCheckboxProps) {
  const accent = TONE_STYLES[tone].hex;
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (disabled) return;
        pixelSound.play(checked ? "toggleOff" : "toggleOn");
        onChange(!checked);
      }}
      className={`group flex items-start gap-3 text-left font-mono-hud cursor-pointer select-none ${
        disabled ? "opacity-50 cursor-not-allowed" : ""
      } ${className}`}
    >
      <div
        className="w-5 h-5 mt-0.5 border-2 border-[#090B10] shadow-[2px_2px_0_#040508] flex items-center justify-center shrink-0 transition"
        style={{
          backgroundColor: checked ? accent : "#090B10",
          outline: `2px solid ${checked ? accent : "#475569"}`,
        }}
      >
        {checked && <PixelIcon name="check" size={13} color="#090B10" />}
      </div>
      <div className="min-w-0">
        <div className="text-xs sm:text-sm font-bold text-[#F5F2EB] group-hover:text-white">
          {label}
        </div>
        {description && (
          <div className="text-[11px] text-[#94A3B8] leading-snug">
            {description}
          </div>
        )}
      </div>
    </button>
  );
}

export interface PixelRadioOption {
  value: string;
  label: string;
  description?: string;
  badge?: string;
}

export interface PixelRadioGroupProps {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  options: PixelRadioOption[];
  tone?: PixelColorTone;
  className?: string;
}

export function PixelRadioGroup({
  label,
  value,
  onChange,
  options,
  tone = "cyan",
  className = "",
}: PixelRadioGroupProps) {
  const accent = TONE_STYLES[tone].hex;
  return (
    <div className={`space-y-2 font-mono-hud ${className}`}>
      {label && (
        <div className="font-pixel text-[10px] font-bold text-[#F5F2EB] uppercase">
          {label}
        </div>
      )}
      <div className="space-y-2">
        {options.map((opt) => {
          const active = opt.value === value;
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => {
                pixelSound.play("click");
                onChange(opt.value);
              }}
              className={`w-full p-2.5 border-2 border-[#090B10] shadow-[3px_3px_0_#040508] text-left flex items-center justify-between gap-3 cursor-pointer transition ${
                active ? "bg-[#161F33]" : "bg-[#090B10] hover:bg-[#111622]"
              }`}
              style={{ outline: `2px solid ${active ? accent : "#2A344B"}` }}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className="w-4 h-4 border-2 border-[#090B10] flex items-center justify-center shrink-0"
                  style={{
                    backgroundColor: "#090B10",
                    outline: `2px solid ${active ? accent : "#64748B"}`,
                  }}
                >
                  {active && (
                    <div
                      className="w-2 h-2"
                      style={{ backgroundColor: accent }}
                    />
                  )}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate">
                    {opt.label}
                  </div>
                  {opt.description && (
                    <div className="text-[11px] text-[#94A3B8] truncate">
                      {opt.description}
                    </div>
                  )}
                </div>
              </div>
              {opt.badge && (
                <span
                  className="px-1.5 py-0.5 font-pixel text-[10px] font-bold text-[#090B10] shrink-0"
                  style={{ backgroundColor: accent }}
                >
                  {opt.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export interface PixelCollapseItem {
  id: string;
  title: string;
  subtitle?: string;
  badge?: string;
  icon?: PixelIconName;
  content: React.ReactNode;
}

export interface PixelCollapseProps {
  items: PixelCollapseItem[];
  defaultOpenIds?: string[];
  allowMultiple?: boolean;
  tone?: PixelColorTone;
  className?: string;
}

export function PixelCollapse({
  items,
  defaultOpenIds = [],
  allowMultiple = true,
  tone = "yellow",
  className = "",
}: PixelCollapseProps) {
  const [openIds, setOpenIds] = useState<string[]>(defaultOpenIds);
  const accent = TONE_STYLES[tone].hex;

  const toggleItem = (id: string) => {
    const isOpen = openIds.includes(id);
    pixelSound.play(isOpen ? "toggleOff" : "toggleOn");
    if (allowMultiple) {
      setOpenIds((prev) =>
        isOpen ? prev.filter((item) => item !== id) : [...prev, id]
      );
    } else {
      setOpenIds(isOpen ? [] : [id]);
    }
  };

  return (
    <div className={`space-y-2.5 font-mono-hud ${className}`}>
      {items.map((item) => {
        const isOpen = openIds.includes(item.id);
        return (
          <div
            key={item.id}
            className="bg-[#090B10] border-2 border-[#090B10] shadow-[4px_4px_0_#040508]"
            style={{ outline: `2px solid ${isOpen ? accent : "#2A344B"}` }}
          >
            <button
              type="button"
              onClick={() => toggleItem(item.id)}
              aria-expanded={isOpen}
              aria-controls={`px-collapse-${item.id}`}
              className={`w-full px-3.5 py-2.5 text-left flex items-center justify-between gap-3 cursor-pointer transition ${
                isOpen ? "bg-[#151D2E]" : "bg-[#111622] hover:bg-[#151D2E]"
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <PixelIcon
                  name={item.icon || (isOpen ? "folder-open" : "folder")}
                  size={15}
                  color={isOpen ? accent : "#94A3B8"}
                />
                <div className="min-w-0">
                  <div className="font-display text-xs sm:text-sm font-bold text-white truncate">
                    {item.title}
                  </div>
                  {item.subtitle && (
                    <div className="text-[11px] text-[#94A3B8] truncate">
                      {item.subtitle}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {item.badge && (
                  <span
                    className="px-2 py-0.5 font-pixel text-[10px] font-bold text-[#090B10]"
                    style={{ backgroundColor: accent }}
                  >
                    {item.badge}
                  </span>
                )}
                <PixelIcon
                  name={isOpen ? "chevron-up" : "chevron-down"}
                  size={14}
                  color={accent}
                />
              </div>
            </button>
            {isOpen && (
              <div
                id={`px-collapse-${item.id}`}
                className="p-3.5 bg-[#090B10] border-t-2 border-[#1E2638] text-xs sm:text-sm text-[#CBD5E1] leading-relaxed"
              >
                {item.content}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export interface PixelCalendarEvent {
  date: string; // YYYY-MM-DD
  label: string;
  tone?: PixelColorTone;
}

export interface PixelCalendarProps {
  selectedDate?: string; // YYYY-MM-DD
  onSelectDate?: (date: string) => void;
  events?: PixelCalendarEvent[];
  tone?: PixelColorTone;
  lang?: "es" | "en";
  className?: string;
}

export function PixelCalendar({
  selectedDate = "2026-10-30",
  onSelectDate,
  events = [],
  tone = "cyan",
  lang = "es",
  className = "",
}: PixelCalendarProps) {
  const initialParts = selectedDate.split("-").map(Number);
  const [year, setYear] = useState(initialParts[0] || 2026);
  const [month, setMonth] = useState((initialParts[1] || 10) - 1); // 0-indexed
  const accent = TONE_STYLES[tone].hex;

  const monthNamesEs = [
    "ENERO",
    "FEBRERO",
    "MARZO",
    "ABRIL",
    "MAYO",
    "JUNIO",
    "JULIO",
    "AGOSTO",
    "SEPTIEMBRE",
    "OCTUBRE",
    "NOVIEMBRE",
    "DICIEMBRE",
  ];
  const monthNamesEn = [
    "JANUARY",
    "FEBRUARY",
    "MARCH",
    "APRIL",
    "MAY",
    "JUNE",
    "JULY",
    "AUGUST",
    "SEPTEMBER",
    "OCTOBER",
    "NOVEMBER",
    "DECEMBER",
  ];
  const weekDaysEs = ["LU", "MA", "MI", "JU", "VI", "SA", "DO"];
  const weekDaysEn = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];

  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const startOffset = (firstDayOfMonth + 6) % 7; // Monday = 0
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const prevMonth = () => {
    pixelSound.play("click");
    if (month === 0) {
      setMonth(11);
      setYear((y) => y - 1);
    } else {
      setMonth((m) => m - 1);
    }
  };

  const nextMonth = () => {
    pixelSound.play("click");
    if (month === 11) {
      setMonth(0);
      setYear((y) => y + 1);
    } else {
      setMonth((m) => m + 1);
    }
  };

  const formatIso = (d: number) =>
    `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

  const activeEvent = events.find((e) => e.date === selectedDate);

  return (
    <div
      className={`bg-[#090B10] border-2 border-[#090B10] shadow-[5px_5px_0_#040508] p-3.5 font-mono-hud space-y-3 ${className}`}
      style={{ outline: `2px solid ${accent}` }}
    >
      {/* Calendar Header */}
      <div className="flex items-center justify-between gap-2 bg-[#111622] p-2 border border-[#2A344B]">
        <button
          type="button"
          onClick={prevMonth}
          className="px-2.5 py-1.5 bg-[#090B10] hover:bg-[#1E293B] border border-[#2A344B] cursor-pointer"
        >
          <PixelIcon name="chevron-left" size={13} color={accent} />
        </button>
        <div className="flex items-center gap-1.5 font-pixel text-xs font-bold text-white">
          <PixelIcon name="calendar" size={13} color={accent} />
          <span>
            {(lang === "es" ? monthNamesEs : monthNamesEn)[month]} {year}
          </span>
        </div>
        <button
          type="button"
          onClick={nextMonth}
          className="px-2.5 py-1.5 bg-[#090B10] hover:bg-[#1E293B] border border-[#2A344B] cursor-pointer"
        >
          <PixelIcon name="chevron-right" size={13} color={accent} />
        </button>
      </div>

      {/* Days of Week Header */}
      <div className="grid grid-cols-7 gap-1 text-center">
        {(lang === "es" ? weekDaysEs : weekDaysEn).map((wd) => (
          <div
            key={wd}
            className="font-pixel text-[10px] text-[#94A3B8] py-1 bg-[#111622]"
          >
            {wd}
          </div>
        ))}

        {Array.from({ length: startOffset }).map((_, i) => (
          <div key={`empty-${i}`} className="h-8 bg-[#06080C]" />
        ))}

        {Array.from({ length: daysInMonth }).map((_, idx) => {
          const day = idx + 1;
          const iso = formatIso(day);
          const isSelected = iso === selectedDate;
          const ev = events.find((e) => e.date === iso);
          const evHex = ev
            ? TONE_STYLES[ev.tone || "yellow"].hex
            : undefined;

          return (
            <button
              key={iso}
              type="button"
              onClick={() => {
                pixelSound.play(ev ? "coin" : "click");
                onSelectDate?.(iso);
              }}
              className={`relative h-8 font-mono-hud text-xs font-bold border transition cursor-pointer flex flex-col items-center justify-center ${
                isSelected
                  ? "text-[#090B10] border-[#090B10] shadow-[2px_2px_0_#FFFFFF]"
                  : "bg-[#111622] hover:bg-[#1A2336] text-[#F5F2EB] border-[#1E2638]"
              }`}
              style={{
                backgroundColor: isSelected ? accent : undefined,
              }}
            >
              <span>{day}</span>
              {ev && (
                <span
                  className="w-1.5 h-1.5"
                  style={{
                    backgroundColor: isSelected ? "#090B10" : evHex,
                  }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Selected Date / Event Telemetry Footer */}
      <div className="p-2.5 bg-[#111622] border border-[#2A344B] flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 min-w-0">
          <span
            className="px-2 py-0.5 font-pixel text-[10px] font-bold text-[#090B10] shrink-0"
            style={{ backgroundColor: accent }}
          >
            {selectedDate}
          </span>
          <span className="text-[#CBD5E1] font-bold truncate">
            {activeEvent
              ? activeEvent.label
              : lang === "es"
              ? "Fecha activa en calendario"
              : "Active calendar date"}
          </span>
        </div>
        <PixelIcon name="clock" size={13} color={accent} />
      </div>
    </div>
  );
}

export interface PixelSliderProps {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
  tone?: PixelColorTone;
  className?: string;
}

export function PixelSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = "",
  onChange,
  tone = "emerald",
  className = "",
}: PixelSliderProps) {
  const accent = TONE_STYLES[tone].hex;
  const pct = Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
  const totalBlocks = 16;
  const activeBlocks = Math.round((pct / 100) * totalBlocks);

  return (
    <div className={`space-y-1.5 font-mono-hud ${className}`}>
      <div className="flex items-center justify-between text-xs">
        <span className="font-pixel text-[10px] font-bold text-[#F5F2EB]">
          {label}
        </span>
        <span
          className="px-2 py-0.5 font-pixel text-[10px] font-bold text-[#090B10]"
          style={{ backgroundColor: accent }}
        >
          {value}
          {unit}
        </span>
      </div>
      <div className="relative p-2 bg-[#090B10] border-2 border-[#2A344B]">
        <div className="grid grid-cols-16 gap-1 pointer-events-none">
          {Array.from({ length: totalBlocks }).map((_, i) => (
            <div
              key={i}
              className="h-3.5 transition-colors"
              style={{
                backgroundColor: i < activeBlocks ? accent : "#151C2B",
              }}
            />
          ))}
        </div>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => {
            pixelSound.play("hover");
            onChange(Number(e.target.value));
          }}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </div>
    </div>
  );
}

export interface PixelMultiSeriesPoint {
  label: string;
  values: Record<string, number>;
}

export interface PixelMultiSeriesConfig {
  key: string;
  name: string;
  color: string;
}

export interface PixelMultiLineChartProps {
  title?: string;
  subtitle?: string;
  series: PixelMultiSeriesConfig[];
  data: PixelMultiSeriesPoint[];
  maxY?: number;
  unit?: string;
  className?: string;
}

export function PixelMultiLineChart({
  title,
  subtitle,
  series,
  data,
  maxY = 100,
  unit = "%",
  className = "",
}: PixelMultiLineChartProps) {
  const [hiddenKeys, setHiddenKeys] = useState<string[]>([]);
  const [hoverIdx, setHoverIdx] = useState<number | null>(data.length - 1);

  const toggleSeries = (k: string) => {
    pixelSound.play("click");
    setHiddenKeys((prev) =>
      prev.includes(k) ? prev.filter((x) => x !== k) : [...prev, k]
    );
  };

  // Size the plot from the longest x label (11px monospace ~6.6px/char) so
  // labels never overlap; the SVG never renders below 1:1 (see wrapper).
  const labelW = Math.max(1, ...data.map((d) => d.label.length)) * 6.6;
  const h = 210;
  const padL = Math.max(46, Math.ceil(labelW / 2) + 4);
  const padR = Math.max(18, Math.ceil(labelW / 2) + 4);
  const padT = 18;
  const padB = 32;
  const plotW = Math.max(
    520 - padL - padR,
    Math.ceil(Math.max(0, data.length - 1) * (labelW + 12))
  );
  const w = padL + plotW + padR;
  const plotH = h - padT - padB;

  const getX = (i: number) =>
    padL + (data.length <= 1 ? plotW / 2 : (i / (data.length - 1)) * plotW);
  const getY = (v: number) =>
    padT + plotH - (Math.max(0, Math.min(maxY, v)) / maxY) * plotH;

  return (
    <div
      className={`p-4 bg-[#090B10] border-2 border-[#2A344B] shadow-[5px_5px_0_#040508] font-mono-hud space-y-3 ${className}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          {title && (
            <div className="font-pixel text-xs font-bold text-[#FFD100]">
              {title}
            </div>
          )}
          {subtitle && (
            <div className="text-[11px] text-[#94A3B8]">{subtitle}</div>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {series.map((s) => {
            const hidden = hiddenKeys.includes(s.key);
            return (
              <button
                key={s.key}
                type="button"
                onClick={() => toggleSeries(s.key)}
                className={`px-2 py-1 border text-[10px] font-bold flex items-center gap-1.5 cursor-pointer transition ${
                  hidden
                    ? "bg-[#090B10] text-[#64748B] border-[#1E2638]"
                    : "bg-[#131824] text-white border-[#2A344B]"
                }`}
              >
                <span
                  className="w-2.5 h-2.5 inline-block border border-[#090B10]"
                  style={{ backgroundColor: hidden ? "#475569" : s.color }}
                />
                <span>{s.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Never scale below 1:1 so axis labels stay readable; phones scroll sideways */}
      <div className="overflow-x-auto">
      <svg
        viewBox={`0 0 ${w} ${h}`}
        role="img"
        aria-label={title}
        className="block w-full h-auto bg-[#06080D] border border-[#1E2638]"
        style={{ shapeRendering: "crispEdges", aspectRatio: `${w} / ${h}`, minWidth: w }}
      >
        {/* Horizontal Grid Lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((t, idx) => {
          const y = padT + plotH * (1 - t);
          const val = Math.round(maxY * t);
          return (
            <g key={idx}>
              <line
                x1={padL}
                y1={y}
                x2={w - padR}
                y2={y}
                stroke="#151D2E"
                strokeWidth="1"
              />
              <text
                x={padL - 6}
                y={y + 4}
                textAnchor="end"
                fill="#94A3B8"
                fontSize="11"
                fontFamily="monospace"
              >
                {val}
                {unit}
              </text>
            </g>
          );
        })}

        {/* Series Polylines & Pixel Nodes */}
        {series
          .filter((s) => !hiddenKeys.includes(s.key))
          .map((s) => {
            const pts = data
              .map((d, i) => `${getX(i)},${getY(d.values[s.key] ?? 0)}`)
              .join(" ");
            return (
              <g key={s.key}>
                <polyline
                  fill="none"
                  stroke={s.color}
                  strokeWidth="2.5"
                  points={pts}
                />
                {data.map((d, i) => {
                  const cx = getX(i);
                  const cy = getY(d.values[s.key] ?? 0);
                  return (
                    <rect
                      key={`${s.key}-${i}`}
                      x={cx - 3.5}
                      y={cy - 3.5}
                      width="7"
                      height="7"
                      fill={s.color}
                      stroke="#090B10"
                      strokeWidth="1.5"
                      className="cursor-pointer"
                      onMouseEnter={() => setHoverIdx(i)}
                    />
                  );
                })}
              </g>
            );
          })}

        {/* X Axis Labels */}
        {data.map((d, i) => (
          <text
            key={d.label}
            x={getX(i)}
            y={h - 9}
            textAnchor="middle"
            fill={hoverIdx === i ? "#FFD100" : "#CBD5E1"}
            fontSize="11"
            fontFamily="monospace"
            fontWeight="bold"
          >
            {d.label}
          </text>
        ))}
      </svg>
      </div>

      {hoverIdx !== null && data[hoverIdx] && (
        <div className="p-2 bg-[#111622] border border-[#2A344B] flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="font-pixel text-[10px] text-[#FFD100]">
            BENCHMARK: {data[hoverIdx].label}
          </span>
          <div className="flex flex-wrap items-center gap-3">
            {series
              .filter((s) => !hiddenKeys.includes(s.key))
              .map((s) => (
                <span
                  key={s.key}
                  className="font-bold"
                  style={{ color: s.color }}
                >
                  {s.name}: {data[hoverIdx].values[s.key]}
                  {unit}
                </span>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

export interface PixelDonutGaugeProps {
  label: string;
  sublabel?: string;
  value: number;
  maxValue?: number;
  displayValue?: string;
  tone?: PixelColorTone;
  className?: string;
}

export function PixelDonutGauge({
  label,
  sublabel,
  value,
  maxValue = 100,
  displayValue,
  tone = "cyan",
  className = "",
}: PixelDonutGaugeProps) {
  const accent = TONE_STYLES[tone].hex;
  const pct = Math.max(0, Math.min(1, value / maxValue));
  const segments = 16;
  const activeCount = Math.round(pct * segments);

  return (
    <div
      className={`p-3.5 bg-[#090B10] border-2 border-[#2A344B] shadow-[4px_4px_0_#040508] flex items-center gap-3.5 font-mono-hud ${className}`}
    >
      <svg
        width="68"
        height="68"
        viewBox="0 0 68 68"
        className="shrink-0"
        style={{ shapeRendering: "crispEdges" }}
      >
        {Array.from({ length: segments }).map((_, i) => {
          const angle = (i / segments) * Math.PI * 2 - Math.PI / 2;
          const r = 25;
          const x = Math.round(34 + Math.cos(angle) * r) - 3;
          const y = Math.round(34 + Math.sin(angle) * r) - 3;
          const active = i < activeCount;
          return (
            <rect
              key={i}
              x={x}
              y={y}
              width="6"
              height="6"
              fill={active ? accent : "#1A2234"}
            />
          );
        })}
        <text
          x="34"
          y="37"
          textAnchor="middle"
          fill="#F5F2EB"
          fontSize="11"
          fontFamily="monospace"
          fontWeight="bold"
        >
          {displayValue || `${Math.round(pct * 100)}%`}
        </text>
      </svg>
      <div className="min-w-0">
        <div
          className="font-pixel text-[10px] font-bold truncate"
          style={{ color: accent }}
        >
          {label}
        </div>
        {sublabel && (
          <div className="text-xs text-[#CBD5E1] font-bold mt-0.5 leading-snug">
            {sublabel}
          </div>
        )}
      </div>
    </div>
  );
}

